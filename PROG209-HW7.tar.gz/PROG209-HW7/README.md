# PROG209-HW7

A task manager extended in functionality from HW5's collaboration with Nicholas Jones.

Now put on a web server.

## Instructions:

Continuing on from last weeks assignment, you need to make your 4th page work.  So you will have a home page plus at least 3 other pages, and each of those 3 pages are using common data from your object array.  One of those pages needs to have a `<ul>` with `<li>`'s that are clickable and do something which is unique for each `<li>`.

Once you have that working, then create a node.js web server and copy into it your HTML, JS, CSS, and image files.  I went over this twice in Monday's class, so you should not have much trouble.  Remember, you will likely have to change the top of your HTML file as your JS and CSS files will be in slightly different directories.
